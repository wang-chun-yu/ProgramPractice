#define FSM_BUILD_SAMPLE2
#include "fsm.hpp"

