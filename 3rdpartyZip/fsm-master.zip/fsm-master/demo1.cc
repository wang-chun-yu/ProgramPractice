#define FSM_BUILD_SAMPLE1
#include "fsm.hpp"

